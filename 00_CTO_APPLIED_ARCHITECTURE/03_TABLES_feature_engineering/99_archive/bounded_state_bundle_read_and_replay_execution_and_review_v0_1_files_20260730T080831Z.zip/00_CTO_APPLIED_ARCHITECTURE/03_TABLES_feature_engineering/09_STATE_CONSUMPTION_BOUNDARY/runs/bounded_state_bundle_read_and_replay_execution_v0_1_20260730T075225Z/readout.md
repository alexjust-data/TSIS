# Bounded StateBundle Read and Replay Execution Readout v0.1

Gate: `bounded_state_bundle_read_and_replay_execution_v0_1`
Run: `bounded_state_bundle_read_and_replay_execution_v0_1_20260730T075225Z`
Date: `2026-07-30`
Status: `CLOSED_PASS_ONE_BOUNDED_MARKET_STATE_PHYSICAL_READ_AND_REPLAY_PROBE_WITH_RESTRICTIONS`

```text
physical_data_files_opened = 1
physical_state_rows_read = 2
bounded_probe_records_emitted = 2
early_deliveries = 0
unlisted_rows_delivered = 0
strategy_callbacks = 0
signals = 0
orders = 0
fills = 0
PnL = false
datasets_written = 0
registry_mutations = 0
production = false
downstream = false
```

The single-use authorization was consumed by this run. The exact ACIU records
for 2021-03-15 were hash-verified, schema-validated, fingerprint-recalculated,
joined one-to-one with replay availability evidence and emitted only when the
probe clock reached `state_available_at_utc`.

This is bounded integration evidence, not general `StateReplayFeed` or backtest
strategy-consumption authority.

## Next Gate

```text
bounded_state_bundle_read_and_replay_review_v0_1
```
